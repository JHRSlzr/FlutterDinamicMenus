import 'package:flutter/material.dart';

class Descripcion extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Desription page')
        ),
        body: Text('Bienvenido a la página de descripción')
      );
  }
}
